1. permissions
READ_EXTERNAL_STORAGE

2 resources
drawable/ic_add_photo.xml
